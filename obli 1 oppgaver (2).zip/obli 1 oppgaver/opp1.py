Hei = str("Hello World")
print(Hei)