F_Navn = str("Anker")
E_Navn = str("Ahet")
Alder = int(20)

print(f"Hei. Jeg heter {F_Navn} {E_Navn} og er {Alder} år gammel")