x = 9
while x <= 101:
    if x % 2 != 0:
          print(x)
    x += 1
