a = int(input("Hva er svaret på det ultimate spørsmålet om livet, universet og alle ting? Hint: Det er et tall."))
if a == 42:
    print("Det stemmer, meningen med livet er 42!")
elif a < 50 and a > 30:
    print("Nærme, men feil")
else:
    print("Feil")